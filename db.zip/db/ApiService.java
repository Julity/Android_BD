package com.example.myapplication.db;
// ApiService.java

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface ApiService {
    @POST("api.php") // Замените на имя вашего PHP-скрипта
    Call<Void> addData(@Body MyDataModel data);
}

