package com.example.myapplication.db;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDbHelper extends SQLiteOpenHelper {
    private Context context;
    public MyDbHelper(@Nullable Context context) {

        super(context, MyConstants.DB_NAME, null, MyConstants.DB_VERSION);
        this.context = context;


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(MyConstants.TABLE_STRUCTURE);
        } catch (SQLException e) {
            e.printStackTrace();

        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {//при изменении старая дб перезаписывается на новую
        try {
            db.execSQL(MyConstants.DPOR_TABLE);
            onCreate(db);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "Error upgrading database: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
