package com.example.myapplication.db;

// MyDataModel.java
public class MyDataModel {
    private String title;
    private String disc;

    public MyDataModel(String title, String disc) {
        this.title = title;
        this.disc = disc;
    }
}
