package com.example.myapplication.db;

public class MyConstants {
    public static final String TABLE_NAME="my_table";//название таблицы
    public static final String _ID="_id";//название 1 колоны - идентификатор
    public static final String TITLE="title";//2 колонка
    public static final String DISC="disc";//дискрипшин
    public static final String DB_NAME="lab5.db";//название дб
    public static final int DB_VERSION = 1;//версия
    //Для создания таблицы(структура)
    public static final String TABLE_STRUCTURE =
            "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" +
                    _ID + " INTEGER PRIMARY KEY, " +
                    TITLE + " TEXT, " +
                    DISC + " TEXT)";


    //Для удаления таблицы
    public static final String DPOR_TABLE="DROP TABLE IF EXISTS "+TABLE_NAME;//Сбрасываем если существует
}

