package com.example.myapplication.db;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MyDbManager {
    private Context context;
private  MyDbHelper myDbHelper;//оздает и обновляет дб
    private SQLiteDatabase db;
    public MyDbManager(Context context) {
        this.context = context;
        myDbHelper=new MyDbHelper(context);
    }
    public void openDb(){

        db=myDbHelper.getWritableDatabase();//открываем для записи и тогда для считывания тоже будет работать//
        //Toast.makeText(context, "Li2", Toast.LENGTH_LONG).show();
        if (db != null) {
            Log.d("MyDbManager", "Database opened successfully.");
        } else {
            Log.e("MyDbManager", "Failed to open the database.");
        }
    }
    public void insertToDb(String title, String disc){// для записи
        ContentValues cv =new ContentValues();
        cv.put(MyConstants.TITLE,title);
        cv.put(MyConstants.DISC,disc);
        db.insert(MyConstants.TABLE_NAME,null,cv);
        }
     //для считывания
    public List<String> getFromDb(){
        List<String> tempList=new ArrayList<>();
        Cursor cursor= db.query(MyConstants.TABLE_NAME,null,null,null,
                null,null,null);
        //считывание с курсора
        while (cursor.moveToNext()){
           @SuppressLint("Range")
            String title = cursor.getString(cursor.getColumnIndex(MyConstants._ID))+ " - "+cursor.getString(cursor.getColumnIndex(MyConstants.TITLE))+" - "+cursor.getString(cursor.getColumnIndex(MyConstants.DISC));
            tempList.add(title);
        }
        cursor.close();
        return tempList;
    }

    public void deleteFromDb(String keyword) {
        List<String> searchResults = new ArrayList<>();
        String selection = MyConstants.TITLE + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + keyword + "%"};
        db.delete(MyConstants.TABLE_NAME, selection, selectionArgs);
    }
    public void clearDatabase() {
        db.execSQL("DELETE FROM " + MyConstants.TABLE_NAME);
    //    db.close();
    }

    public List<String> searchInDb(String keyword) {
        List<String> searchResults = new ArrayList<>();
        String selection = MyConstants.TITLE + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + keyword + "%"};

        Cursor cursor = db.query(
                MyConstants.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(MyConstants.TITLE));
            searchResults.add(title);
        }

        cursor.close();
        return searchResults;
    }
    public void closeDb(){
        myDbHelper.close();
    }
}
